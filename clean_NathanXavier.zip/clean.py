#!/usr/bin/env python

import rospy
import math
import time
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from std_srvs.srv import Empty

class Turtle(object):
    def __init__(self,pose_x = 0, pose_y = 0, pose_yaw = 0, 
                 vel_x = 0, vel_y = 0, vel_z = 0, 
                 ang_x = 0, ang_y = 0, ang_z = 0):
        self.pose_x = pose_x
        self.pose_y = pose_y
        self.pose_yaw = pose_yaw
        self.vel_x = vel_x
        self.vel_y = vel_y
        self.vel_z = vel_z
        self.ang_x = ang_x
        self.ang_y = ang_y
        self.ang_z = ang_z

turtle = Turtle()

def move(speed, distance, isForward):
    ## Movement
    if(isForward == 1):
        velocity_message.linear.x = abs(speed)
    elif(isForward == 0):
        velocity_message.linear.x = -abs(speed)
    else:
        rospy.loginfo("is Forward must be 0 (back) or 1 (forward)")
        velocity_message.linear.x = 0
    
    velocity_message.linear.y = 0
    velocity_message.linear.z = 0
    velocity_message.angular.x = 0
    velocity_message.angular.y = 0
    velocity_message.angular.z = 0

    ## Distance
    loop_rate = rospy.Rate(100)
    t0 = rospy.get_time()

    current_distance = 0
    if(velocity_message.linear.x != 0):
        while(current_distance < distance):
            velocity_publisher.publish(velocity_message)
            t1 = rospy.get_time()
            current_distance = abs(velocity_message.linear.x) *(t1-t0) #velocity * time
            loop_rate.sleep()
            #print("%.2f -> %.2f" %(current_distance, distance))
    
    velocity_message.linear.x = 0
    velocity_publisher.publish(velocity_message)
    rospy.loginfo("reached")

def rotate(angular_speed, angle, clockwise):
    ## Rotation
    if(clockwise == 1):
        velocity_message.angular.z = -abs(angular_speed)
    elif(clockwise == 0):
        velocity_message.angular.z = abs(angular_speed)
    else:
        rospy.loginfo("clockwise must be 0 (clockwise) or 1 (counter-clockwise)")
        velocity_message.angular.z = 0
    
    velocity_message.linear.x = 0
    velocity_message.linear.y = 0
    velocity_message.linear.z = 0
    
    velocity_message.angular.x = 0
    velocity_message.angular.y = 0

    ## Angle
    loop_rate = rospy.Rate(100)
    t0 = rospy.get_time()

    current_angle = 0
    if(velocity_message.angular.z != 0):
        while(current_angle < angle):
            velocity_publisher.publish(velocity_message)
            t1 = rospy.get_time()
            current_angle = abs(velocity_message.angular.z) *(t1-t0)
            loop_rate.sleep()
            #print("%.2f -> %.2f" %(current_angle, angle))
    
    velocity_message.angular.z = 0
    velocity_publisher.publish(velocity_message)
    rospy.loginfo("reached")

def setAbsoluteOrientation(desired_angle):
    relative_angle = desired_angle -turtle.pose_yaw
    Clockwise = True if relative_angle<0 else False
    rotate(abs(relative_angle), abs(relative_angle), Clockwise)

def moveGoal(goal_x, goal_y, tolerance):
    loop_rate = rospy.Rate(100)
    
    #print("%.2f -> %.2f" %(getDistance(turtle.pose_x, goal_x, turtle.pose_y, goal_y), tolerance))
    while(abs(getDistance(turtle.pose_x, goal_x, turtle.pose_y, goal_y)) > tolerance):
        loop_rate.sleep()
        velocity_message.linear.x = getDistance(turtle.pose_x, goal_x, turtle.pose_y, goal_y)
        velocity_message.linear.y = 0
        velocity_message.linear.z = 0
        velocity_message.angular.x = 0
        velocity_message.angular.y = 0

        ang = math.atan2(goal_y -turtle.pose_y, goal_x -turtle.pose_x)-turtle.pose_yaw

        sign_ang = math.copysign(1,(ang))
        dir_ang = (sign_ang*ang)%(2*math.pi)

        if((sign_ang > 0 and dir_ang < math.pi) or (sign_ang < 0 and dir_ang > math.pi)):
            turn = 1
            print("Gira Esq")
        elif((sign_ang > 0 and dir_ang > math.pi) or (sign_ang < 0 and dir_ang < math.pi)):
            turn = -1
            print("Gira Dir")
        else:
            turn = 0
            print("Reto")

        velocity_message.angular.z = turn
        
        #print("\n\nPos: %.2f -> %.2f" %(velocity_message.linear.x, velocity_message.angular.z))
        #print("Ang: %.2f -> %.2f" %(math.atan2(goal_y -turtle.pose_y, goal_x -turtle.pose_x), turtle.pose_yaw))
        velocity_publisher.publish(velocity_message)

    
    velocity_message.linear.x = 0
    velocity_message.angular.z = 0
    velocity_publisher.publish(velocity_message)
    rospy.loginfo("reached")

def getDistance(x1, x2, y1, y2):
    dx = x2 -x1
    dy = y2 -y1
    return math.sqrt(dx**2 +dy**2)

def gridClean():
    moveGoal(1, 1, 0.01)
    setAbsoluteOrientation(0)

    move(2, 9, True)
    rotate(math.radians(10), math.radians(90), False)
    move(2, 9, True)
    
    rotate(math.radians(10), math.radians(90), False)
    move(2, 1, True)
    rotate(math.radians(10), math.radians(90), False)
    move(2, 9, True)

    rotate(math.radians(30), math.radians(90), False)
    move(2, 1, True)
    rotate(math.radians(30), math.radians(90), False)
    move(2, 9, True)

def spiralClean():
    loop_rate = rospy.Rate(100)

    while(turtle.pose_x<10.5 and turtle.pose_y<10.5):
        loop_rate.sleep()

        velocity_message.linear.x += 0.005
        velocity_message.linear.y = 0
        velocity_message.linear.z = 0
        velocity_message.angular.x = 0
        velocity_message.angular.y = 0
        velocity_message.angular.z = 4
        
        velocity_publisher.publish(velocity_message)

    
    velocity_message.linear.x = 0
    velocity_message.angular.z = 0
    velocity_publisher.publish(velocity_message)
    rospy.loginfo("reached")

def poseCallback(pose_message):
    turtle.pose_x = pose_message.x
    turtle.pose_y = pose_message.y
    turtle.pose_yaw = pose_message.theta

def clean():
    # Create Variable
    global velocity_message
    global velocity_publisher

    Speed = 0
    Distance = 0
    isForward = 0

    velocity_message = Twist()
    velocity_publisher = rospy.Publisher(velocity_turtle_topic, Twist, queue_size=10)
    
    # ## Move Forward
    # print("Speed: ")
    # Speed = input()
    # print("Distance: ")
    # Distance = input()
    # print("isForward: ")
    # isForward = input()
    # print("\nMove Forward: %.1f %.1f %.1f" %(Speed, Distance, isForward))

    # move(Speed, Distance, isForward)
    
    # ## Rotate
    # print("\nSpeed Rotation: ")
    # Rotation = input()
    # print("Angle: ")
    # Angle = input()
    # print("Clockwise: ")
    # Clockwise = input()
    # print("\nRotate: %.1f %.1f %.1f" %(Rotation, Angle, Clockwise))

    # rotate(math.radians(Rotation), math.radians(Angle), Clockwise)
    
    # ## Angle Desired
    # print("\nAngle Desired: ")
    # Angle_Desired = input()
    # print("\nAngle Desired: %.1f" %(Angle_Desired))

    # setAbsoluteOrientation(math.radians(Angle_Desired))
    
    # ## Rotate
    # print("\nGoal Position X: ")
    # Goal_x = input()
    # print("Goal Position Y: ")
    # Goal_y = input()
    # print("Tolerance: ")
    # Tolerance = input()
    # moveGoal(Goal_x, Goal_y, Tolerance)


    print("Action: ")
    Action = input()
    if(Action == 1):
        ## Grid
        gridClean()
    elif(Action == 2):
        ## Spiral
        spiralClean()
    
if __name__ == '__main__':
    try:
        rospy.init_node('turtlecleaner', anonymous=True)
        velocity_turtle_topic = "/turtle1/cmd_vel"
        position_turtle_topic = "/turtle1/pose"
        pose_subscriber = rospy.Subscriber(position_turtle_topic, Pose, poseCallback)

        clean()
        rospy.spin()
       
    except rospy.ROSInterruptException:
        rospy.loginfo("node terminated.")